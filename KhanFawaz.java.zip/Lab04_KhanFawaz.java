import edu.fcps.karel2.Display;
import edu.fcps.karel2.Robot;

public class Lab04_KhanFawaz
{
   public static void runTheRace(Racer arg)throws InterruptedException
   {     
               
      arg.shuttle(2,7);
      arg.shuttle(4,5);
      arg.shuttle(6,3);
   }       
  
   public static void main(String[] args) throws InterruptedException
   {
      Display.openWorld("maps/shuttle.map");
      Display.setSize(10, 10);
      Display.setSpeed(6);
      Racer Billford = new Racer(1);
      Racer Jesus = new Racer(4);
      Racer Bill = new Racer(7);
      runTheRace(Bill);
      Bill.move();
      runTheRace(Jesus);
      Jesus.move();
      runTheRace(Billford);
      Billford.move();


      
      
           
      
           
      
      


      

      
      
      
     
      



        
      
      
      
   }
}