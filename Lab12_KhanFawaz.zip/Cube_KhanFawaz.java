public class Cube_KhanFawaz extends My3DObject_KhanFawaz
{    
   private double Volume = 0;
   private double SurfaceArea = 0;
   private double objectEdge =  0;


   
   public double getEdge()
   
   {
      return objectEdge;
   }
   
   public void setEdge(double edge)
   {
      objectEdge = edge;
      
   }
   public double getVolume()
   
   {
      return Volume;
   }
     


   
   public void calculateVolume()
   {
      Volume =objectEdge * objectEdge * objectEdge ;
   }
     

public double getSurfaceArea()
   
   {
      return SurfaceArea;
   }
     

   public void calculateSurfaceArea()
   {
      SurfaceArea = 6 * (objectEdge *  objectEdge);
   }
     


   
}