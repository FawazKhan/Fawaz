public class RectangularPrism_KhanFawaz extends My3DObject_KhanFawaz
{
   private double Volume = 0;
   private double Length = 0; 
   private double Width = 0;
   private double Height = 0;
   private double SurfaceArea = 0;

   
   public double getLength()
   {
      return Length;
   }
   public void setLength(double l)
   {  
      Length = l;
   }  

   public double getWidth()   
   {  
      return Width; 
   }  
   public void setWidth(double w)
   {  
      Width = w;
   }
   public double getHeight()   
   {  
      return Height; 
   }  
   public void setHeight(double h)
   {  
      Height = h;
   }  
  

   public double getVolume()
   {
      return Volume;      
   }
   public void calculateVolume()
   {
      Volume = (Width*Height*Length);      
   }
   public double getSurfaceArea()
   {
      return SurfaceArea;      
   }

   public void calculateSurfaceArea()
   {
      SurfaceArea = 2*(Width*Length+Height*Length+Height*Length);     
   }
   
}