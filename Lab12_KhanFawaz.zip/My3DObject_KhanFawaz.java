public abstract class My3DObject_KhanFawaz
{
   //Create private strings called objectName and objectColor


   //No need for a constructor since we will have getters and setters
   
   //Fill in the getters and setters below
   private String objectName = "" ;
   private String objectColor= "" ;
   private String radius;
   private String height;
   private String width;
   private String length;
   
   

   public String getName() 
   {
      return objectName;
   }
   
   public void setName(String name)
   {
      objectName = name;
   }
   
   public String getColor() 
   {
      return objectColor;   
   }
   
   public void setColor(String color)
   {
      objectColor = color;
   
   }
   
   //Create the two abstract methods that your subclasses know how to do, but they'll do the method differently
   
   
      
   public abstract void calculateVolume();
   public abstract void calculateSurfaceArea();   
   
   
   
   
   
   
}