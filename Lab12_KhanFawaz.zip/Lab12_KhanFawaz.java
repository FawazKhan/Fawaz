import java.util.Scanner;


public class Lab12_KhanFawaz
{
   public static void main(String[] args)
   {
                  
   
   
   
      Scanner input=new Scanner(System.in);
     
   
           
      Cube_KhanFawaz cube = new Cube_KhanFawaz();
      System.out.println("The first shape is a cube");
      
      System.out.println("What is the shape's name?");
      cube.setName(input.nextLine());
      
      System.out.println("What is the shape's color?");
      cube.setColor(input.nextLine());
   
      System.out.println("What is the Edge?");
      cube.setEdge(input.nextDouble());
      System.out.println("The " + cube.getColor()+ " cube's name is " + cube.getName());
   
      System.out.println("The Volume is" + cube.getVolume());
      System.out.println("The Surface Area is" + cube.getSurfaceArea());
      
      Sphere_KhanFawaz sphere = new Sphere_KhanFawaz();
      System.out.println("The first shape is a sphere");
      
      System.out.println("What is the shape's name?");
      sphere.setName(input.nextLine());
      
      System.out.println("What is the shape's color?");
      sphere.setColor(input.nextLine());
      
      System.out.println("What is the shape's radius?");
      sphere.setRadius(input.nextDouble());
   
      
      System.out.println("The " + sphere.getColor()+ " sphere's name is " + sphere.getName());
   
      System.out.println("The Volume is" + sphere.getVolume());
      System.out.println("The Surface Area is" + sphere.getSurfaceArea());
      
      RectangularPrism_KhanFawaz RectangularPrism = new RectangularPrism_KhanFawaz();
      System.out.println("The first shape is a RectangularPrism");
      
      System.out.println("What is the shape's name?");
      RectangularPrism.setName(input.nextLine());
      
      System.out.println("What is the shape's color?");
      RectangularPrism.setColor(input.nextLine());
      
      System.out.println("What is the shape's Length?");
      RectangularPrism.setLength(input.nextDouble());
      
      System.out.println("What is the shape's Height?");
      RectangularPrism.setHeight(input.nextDouble());
      
      System.out.println("What is the shape's Width?");
      RectangularPrism.setWidth(input.nextDouble());
      
      System.out.println("The " + RectangularPrism.getColor()+ " RectangularPrism's name is " + RectangularPrism.getName());
   
      System.out.println("The Volume is" + RectangularPrism.getVolume());
      System.out.println("The Surface Area is" + RectangularPrism.getSurfaceArea());
   
   
      
   
   
            
   
      
      
   
   
   
   
    
      
         
   }
}

