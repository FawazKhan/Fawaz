public class Sphere_KhanFawaz extends My3DObject_KhanFawaz
{
   private double Radius = 0;
   private double Volume = 0;
   private double SurfaceArea = 0;

   public double getRadius()
   {
      return Radius;
   }
   public void setRadius(double r)
   {  
      Radius = r;
   }  
   public double getVolume()
   {
      return Volume;
   }

   public void calculateVolume()
   {
     Volume=(4/3) * Math.PI * (Radius * Radius * Radius);
   }
   public double getSurfaceArea()
   {
      return SurfaceArea;
   }

   public void calculateSurfaceArea()
   {
      SurfaceArea= 4 *Math.PI * (Radius * Radius);
   }
}