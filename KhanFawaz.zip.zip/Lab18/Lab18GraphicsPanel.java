/*
Lab 16 - Lots of Lines
//STUDENT: Update the fields below
Author: Smith, John
Date: Jan. 1, 2019
*/
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.geom.*;
import java.awt.event.*;

public class Lab18GraphicsPanel extends JPanel
{

//STUDENT: Define your private data here. At minimum, this should include the increment
   private int input;
   Ellipse2D bill = new Ellipse2D.Double(360, 100,250,100);
   Line2D todd = new Line2D.Double(400,150,200,200);
   Rectangle rect1  = new Rectangle(400,400,150,150);
   RoundRectangle2D round = new RoundRectangle2D.Double(300, 100, 200, 200, 50, 50);
   int []xPoints = {200,250,225,175,150,200};
   int [] yPoints = {100,200,300,300,200,100};
   Polygon close = new Polygon(xPoints,yPoints,6);
   Shape[] aos = new Shape[5]; 
   Color[]hues = new Color[5];
   int strokeWidth = 15;
   int maxX;
   int maxY;



   public Lab18GraphicsPanel(int user)
   {
   //STUDENT: Set the increment here. You decide how much to increment by!
      input = user;
      switch(input)
      {
         case 5:
            aos[4] = close;
         case 4:
            aos[3] = bill;
         
         case 3:
            aos[2] = round;   
         case 2:
            aos[1] = todd;
         case 1:
            aos[0] = rect1;    
      }
      addKeyListener(new KeyboardHandler());
      
   }
   public void paintComponent(Graphics g) //paintComponent is called on refresh
   {
      Dimension d = this.getSize();
      maxY = (int) d.getHeight();
      maxX = (int) d.getWidth();
      Graphics2D g2 = (Graphics2D) g;
      g2.setStroke(new BasicStroke(strokeWidth,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));
      g.clearRect(0,0,maxX, maxY);
      for (int i=0; i<input; i++)
      {
         g2.setColor(hues[i]);
         g2.draw(aos[i]);
      };
       
   }
   private class KeyboardHandler implements KeyListener
   {
      public void keyPressed(KeyEvent e)
      {
         int key = e.getKeyCode();
         switch (key)
         {
            case KeyEvent.VK_1:
            // ASCII codes used for numbers, so subtract the offset to get us to int
               input = key-48;
               System.out.println("Setting shapes to " + input);
               break;
         // Do you need another case for pressing other numbers?
            case KeyEvent.VK_2:
            // ASCII codes used for numbers, so subtract the offset to get us to int
               input = key-48;
               System.out.println("Setting shapes to " + input);
               break;

               case KeyEvent.VK_3:
            // ASCII codes used for numbers, so subtract the offset to get us to int
               input = key-48;
               break;

               case KeyEvent.VK_4:
            // ASCII codes used for numbers, so subtract the offset to get us to int
               input = key-48;
               System.out.println("Setting shapes to " + input);
               break;
               case KeyEvent.VK_5:
            // ASCII codes used for numbers, so subtract the offset to get us to int
               input = key-48;
               System.out.println("Setting shapes to " + input);
               break;
               
            
            case KeyEvent.VK_UP: // Up key increase strokewidth
               strokeWidth++;
               break;
            case KeyEvent.VK_DOWN: // down key decrease strokewidth
            strokeWidth--;
               break;
            case KeyEvent.VK_RIGHT: // right key change colors
            for(int x = 0; x < hues.length; x++)  
            {
               hues[x] = new Color((int) (Math.random()* 225), (int) (Math.random()* 225), (int) (Math.random()* 225));
            }                                            
            break;
         }
         repaint();
      } 
      
      public void keyTyped(KeyEvent e)
      {
      
      } 
      public void keyReleased(KeyEvent e)
      {
         
      } 
   
   
   } 
   
}
