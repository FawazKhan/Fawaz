public class WarmUp 11


{

   public static void main(String[] args)
   {
      int lookingAt = 0;
      int totalOnTable = 0;
      while(true)
      {
      }
   }
}
