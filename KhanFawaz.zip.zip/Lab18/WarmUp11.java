public class WarmUp11


{

   public static void main(String[] args)
   {
      int lookingAt = 0;
      int totalOnTable = 0;
      while(true)
      {  
         if (lookingAt< 10)
         {
            lookingAt++;
         }
         else
         {
            lookingAt= 1;
         }
         if (totalOnTable < 10)
         {
            totalOnTable++;            System.out.println("The apple I am looking at is apple #" + lookingAt);
         System.out.println("Total # of apples is" + totalOnTable);

      }
   }
}
}
