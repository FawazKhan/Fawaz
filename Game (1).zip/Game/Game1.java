import java.awt.*; // Using AWT layouts
import javax.swing.*; // Using Swing components and containers

public class Game1 extends JFrame
{
   private Game1GraphicsPanel centerPanel;
// Constructor to setup the GUI components and event handlers
   public Game1()
   {
      Container cp = getContentPane();
      centerPanel = new Game1GraphicsPanel();
      centerPanel.setFocusable(true);
      centerPanel.requestFocus();
      cp.setLayout(new BorderLayout());
      cp.add(centerPanel, BorderLayout.CENTER);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("Game1"); //STUDENT: replace with title of the lab
      setSize(840, 590); //STUDENT: replace with sufficiently large X and Y dimension of your choice
      setVisible(true);
   }
   public static void main(String[] args) {
   // Run the GUI construction in the Event-Dispatching thread for thread-safety
      SwingUtilities.invokeLater(
         new Runnable() {
            @Override
            public void run() {
               new Game1(); // Let the construct5
               //or do the job
            }
         });
   }
   }