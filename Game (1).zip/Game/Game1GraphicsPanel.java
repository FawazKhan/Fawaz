import java.awt.*;//imports everything I need to run the code
import java.awt.event.*;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionListener;
//cyan = cy ; red = rd pink = p blue = bl green = gr black = bk

public class Game1GraphicsPanel extends JPanel implements ActionListener   {  
   Timer time = new Timer (5,this);//the timer is created here, it updates every 5 miliseconds 
                                   //The timer is crucial because it counts up to the milisecond I put in
                                   // causing it to call on ActionListener
                                   //and calls on this which is the ActionListener
                                   //The ActionListener's purpose is to essentially have all the variables and objects
                                   //set for the actionpreformed class to call on
                                   //ActionListener is the precursor to actionpreformed and I set numbers to these variables
                                 //to either replace their x or y coordinate this would be helpful if I need to later animate or move a certain object


    //these lines either make a variable that a will use later be set to a certain point,which takes place of X or Y
    //Also some of the lines set the speed of the rectangle,ex:cyspeed means cyan rectangle's speed is set to___
   int l=200;
   int bk = 3;
   int p = 3;
   int cy = 3;                  
   int rd = 769;
   int gr =769;
   int bl = 769;
   int cyspeed = -10;//sets the speed of the rectangle to a certain speed
   int pspeed = -10;
   int bkspeed = -10;
   int rdspeed =15;
   int grspeed = 15;
   int blspeed = 15;
   int y = 10;
   int r = 10;
   int maxX= 840;
   int maxY= 590;   
   Rectangle red = new Rectangle (rd,210,50,30);//This is where I first create the rectangles I will use later on
   Rectangle green = new Rectangle (gr,210,50,30);
   Rectangle black = new Rectangle(bk,210,50,30);
   Rectangle cyan = new Rectangle(cy, 310,50,30);
   Rectangle blue = new Rectangle(bl, 410,50,30);
   Rectangle pink= new Rectangle(p, 510,50,3);         
   Rectangle wall = new Rectangle (5, 4,4,545);
   Rectangle wall2 = new Rectangle (820, 4,4,545);
   Rectangle object =  new Rectangle(1, y, 25, 25);
   Rectangle trophy = new Rectangle( 10, 10,25,25);
   
   public Game1GraphicsPanel() 
   {
      
      addKeyListener(new KeyboardHandler());//essentially makes my Keyboard Handler work as the KeyListener is  added to it
                                            //which is the only reason it works
   
   
   }
   
   
   public void paintComponent(Graphics g) //paintComponent is called on refresh
   {
      Dimension d = this.getSize();
      maxY = (int) d.getHeight();
      maxX = (int) d.getWidth();
      g.clearRect(0,0,maxX, maxY);
      Graphics2D g2 = (Graphics2D) g;
    
      //g2.drawImage(box2, 6, y, null);//top corner (6,210)
      g.setColor(Color.ORANGE);
      g2.fill(object);
      g.setColor(Color.YELLOW);
      g2.fill(trophy);
      g.setColor(Color.BLACK);
      g.fillRect(bk,150,50,30);
      g.setColor(Color.GREEN);
      g.fillRect(gr,300,50,30);
      g.setColor(Color.BLUE);
      g.fillRect(bl, 410,50,30);
      g.setColor(Color.CYAN);      
      g.fillRect(cy, 360,50,30);
      g.setColor(Color.RED);
      g.fillRect(rd,215,50,30);
      g.setColor(Color.PINK);
      g.fillRect(p, 488,50,30);
      g.setColor(Color.BLACK);
      g.drawRect(5, 4,4,545);
      g.drawRect(820, 4,4,545);
      //Lines above draw the rectangles to a certain colar and to a certain place in the panel
      // Since I have created the rectangles/other objects above 
      //I set the coordinates to it as I have already drawn them above
      trophy = new Rectangle( 405, 526,25,25);      
      object =  new Rectangle(l, y, 25, 25);
      red = new Rectangle (rd,210,50,30);
      green = new Rectangle (gr,210,50,30);
      black = new Rectangle(bk,210,50,30);
      cyan = new Rectangle(cy, 310,50,30);
      blue = new Rectangle(bl, 410,50,30);
      pink = new Rectangle(p, 510,50,3);         
      wall = new Rectangle (5, 4,4,545);
      wall2 = new Rectangle (820, 4,4,545);
    
      time.start();//starts the timer
   
        
   }
        
   public void actionPerformed(ActionEvent e)
   {
      rd = rd + rdspeed;//these lines of code inside of actionPerformed 
                        //make the object by replacing with x value with the speed value causing it to move
      gr = gr + grspeed;
      bl = bl + blspeed;
      p = p + pspeed;
      cy = cy + cyspeed;
      bk = bk + bkspeed;
   
      
       //These lines of code are my collision checkers. 
       //They essentially check to see if my object(player) touches a certain rectangle and if it does, 
       //the speed of that rectangle would be set to 0 causing it to stop. 
      if ( object.intersects(cyan))         
      {
         cyspeed = 0;  
         System.out.println("YOU LOST");//prints statement
      }
      if ( object.intersects(red))         
      {
         rdspeed = 0;  
         System.out.println("YOU LOST");//prints statement
      }
      if ( object.intersects(green))         
      {
         grspeed = 0;  
         System.out.println("YOU LOST");//prints statement
      }
         
      if ( object.intersects(black))         
      {
         bkspeed = 0;  
         System.out.println("YOU LOST");//prints statement
      }
      if ( object.intersects(blue))         
      {
         blspeed = 0;  
         System.out.println("YOU LOST");//prints statement
      }
      if ( object.intersects(pink))         
      {
         pspeed = 0;  
         System.out.println("YOU LOST");  //prints statement      
      }
   
      if ( object.intersects(trophy))   //if object touches the trophy then everything stops      
      {
         cyspeed = 0;
         pspeed = 0;
         blspeed = 0;  
         grspeed = 0;  
         rdspeed = 0; 
         bkspeed = 0;
         System.out.println("WIN");      //prints statement 
      
      }
      //These lines of code cause my rectangles to collide with the wall and bounce of them
      //In my code I have 3 rectangles starting on the right wall and three starting on the left wall
      //If the start on the left wall I set the speed to a negative number to get it to move in the right direction
      // and then I set it to a positive just as it collides with the other wall, this would make it bounce off
      //This logic is flipped for the other wall
      
      
      if( wall.intersects(blue))         
      {
         blspeed = 3;         
      }
      if( wall2.intersects(blue))         
      {
         blspeed = -3;         
      }
      if( wall.intersects(red))         
      {
         rdspeed = 3;         
      }
      if( wall2.intersects(red))         
      {
         rdspeed = -3;         
      }
   
      if( wall.intersects(pink))         
      {
         pspeed = 3;         
      }
      if( wall2.intersects(pink))         
      {
         pspeed = -3;         
      }
      if( wall.intersects(cyan))         
      {
         cyspeed = 3;         
      }
      if( wall2.intersects(cyan))         
      {
         cyspeed = -3;         
      }
   
      if( wall.intersects(black))         
      {
         bkspeed = 3;         
      }
      if( wall2.intersects(black))         
      {
         bkspeed = -3;         
      }
      
      if( wall.intersects(green))         
      {
         grspeed = 3;         
      }
      if( wall2.intersects(green))         
      {
         grspeed = -3;         
      }
   
   
      repaint();// repaint means that it essentially redraws or redoes everything in actionperformed
               // so it would update and function properly
   }
   private class KeyboardHandler implements KeyListener
   { 
      Rectangle object =  new Rectangle(400, y, 25, 25);
      public void keyPressed(KeyEvent e)
      {
         int key = e.getKeyCode();
      
         switch (key)//This is my switch case where I tell my object to move by pressing the corresponding buttons
         {
            case KeyEvent.VK_UP://key that is pressed
            // ASCII codes used for numbers, so subtract the offset to get us to int
               y=y-5;// The y value is set above, so this would me me subtract 5 to the set value causing it to move
                     // up
               
                  
               break;
            case KeyEvent.VK_DOWN://key that is pressed
            
            // ASCII codes used for numbers, so subtract the offset to get us to int
               y=y+5;//The y value is set above, so this would me me add 5 to the set value causing it to move
                     // down
            
               
                  
               break;
            case KeyEvent.VK_RIGHT://key that is pressed
            
            // ASCII codes used for numbers, so subtract the offset to get us to int
               l=l+10; //the l value is set above, so just like y it would get 10 added to it causing it to move  up
               break;
            case KeyEvent.VK_LEFT://key that is pressed
            // ASCII codes used for numbers, so subtract the offset to get us to int
               l=l-10;//the l value is set above, so just like y it would get 10 subtracted to it causing it to move down
         
         }
         repaint();
      }
              
      public void keyTyped(KeyEvent e)
      {
      
      } 
      public void keyReleased(KeyEvent e)
      {
         
      } 
   
   
   }
   
}



 
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
