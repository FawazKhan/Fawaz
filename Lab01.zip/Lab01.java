import java.util.Scanner;
public class Lab01 {
 
 
   public static void main(String args[]){
   
      Scanner scanner = new Scanner(System.in);
      System.out.println("Please enter first number to find GCD");
      int x = scanner.nextInt();
      System.out.println("Please enter second number to find GCD");
      int y = scanner.nextInt();
   
      
    
      System.out.println("GCD of two numbers " + x +" and " 
                        + y +" is :" + GCD(x,y));
      if(GCD(x,y) == 1)
      {
         System.out.println("The numbers are coprime");
      }
      else
      {
         System.out.println("The numbers are cofactors");
      }
      System.out.println("The current ratio is" + 6/Math.PI*Math.PI );
      System.out.println(Math.sqrt(6/Math.PI*Math.PI) - Math.PI/Math.PI + ":percent error");
      


   }

   
     
   public static int GCD(int x, int y) {
      if(y == 0)
      {
         return x;
      }
      return GCD(y, x%y);
   }
}

